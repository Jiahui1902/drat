rm(list=ls())
# save(edurose_mediation_20181126,file = "data/edurose_mediation_20181126.rda",compress = "xz")

library("htetree")
# load("data/edurose_mediation_20181126.rda")

# construct the simulated data based on Athey's data
install.packages("data.table",repos = NULL,
                 type = "source")
library("data.table")
install.packages("causalTree",
                 repos = "https://jiahui1902.github.io/drat/",
                 type = "source")

library(causalTree)
data("simulation.1")
# estimate the propensity score
fit <- glm(treatment~x1+x2+x3+x4+x5+x6+x7+x8+x9+x10,
           data=simulation.1,
           family = "binomial")
simulation.1$ps_score <- predict(fit,type = "response")
linear_terms <- paste0("x",1:10)

# estimate the model with our package
gph <- getwd()
set.seed(1)
lb <- c(paste0("var",1:10),"propensity score")
names(lb) <- c(paste0("x",1:10),"ps_score")

xxx <- htetree::hte_ipw(outcomevariable = 'y',
               minsize=20,crossvalidation = 40,negative = TRUE,
               data = simulation.1,
               ps_indicator = "ps_score",
               drawplot = TRUE,treatment_indicator = "treatment",
               # no_indicater = '_IPW_simulation',
               legend.x = 0.1,legend.y = 0.25,varlabel = lb)

# hte_plot_line(model = xxx,data = simulation.1,
#               treatment_indicator = "treatment",
#               outcomevariable = 'y',
#               propensity_score = "ps_score",gamma = 0.5,lambda = 0.5)
# hte_plot_line(model = xxx,data = simulation.1,
#               treatment_indicator = "treatment",
#               outcomevariable = 'y',
#               propensity_score = "ps_score")


# hte_plot(model = xxx,data = simulation.1,
#          treatment_indicator = "treatment",
#          outcomevariable = 'y',
#          propensity_score = "ps_score")

# hte_plot_line(model = xxx,data = simulation.1,
#               treatment_indicator = "treatment",
#               outcomevariable = 'y',
#               propensity_score = "ps_score")

