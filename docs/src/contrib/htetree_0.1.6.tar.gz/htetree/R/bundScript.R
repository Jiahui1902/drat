#' Include the Javascript Used in Shiny
#'
#' intermediate function used to include necessary javascript
#' to visualize tree structures and estimated treatment effect
#' in shiny


bundScript <- function() {
  includeScript(system.file("js/bundle.js", package = "htetree"))
}
