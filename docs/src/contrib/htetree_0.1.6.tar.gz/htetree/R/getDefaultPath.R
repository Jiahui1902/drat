#' Get the Current Working Directory
#'
#' get the current work directory and set it as the default directory to
#' save the shiny files temporarily
#'
#' @return temporary files saved in the newly created folder titled with
#' in the current directory
#'
getDefaultPath <- function(){
  paste(getwd(), "/shinyapp", sep="")
}

