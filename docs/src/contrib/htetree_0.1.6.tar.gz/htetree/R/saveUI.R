#' Save Shiny UI Temporarily
#'
#' @inheritParams saveFiles

saveUI <- function(filePath){
  bundstr <- "shinyServer(function(input, output) {
})
ui <- fluidPage(
  tags$script(src = 'bundle.js')
)"

  bundsplt <- strsplit(bundstr, "\n")
  bundvec <- unlist(bundsplt)

  fileConn <- file(paste(filePath,"/shinyapp/ui.R",sep=""))
  writeLines(bundvec, fileConn)
  close(fileConn)
}
